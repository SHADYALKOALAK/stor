enum CacheKeys {
  theme,
  language,
  loggedIn,
  id,
  name,
  email,
  fcm,
  lat,
  lng,
  password,
}

enum AppGender { male, female }
