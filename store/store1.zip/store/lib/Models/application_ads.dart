class ApplicationAds {
  String? title;
  String? image;
  String? time1;
  String? time2;
  String? time3;

  ApplicationAds({
    this.title,
    this.image,
    this.time1,
    this.time2,
    this.time3,
  });

}
